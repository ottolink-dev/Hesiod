#!/usr/bin/env bash
set -u
cd /home/barrulus/dev/Hesiod-783
cmake -S external/GNode -B build/gnode-sanitizers -G Ninja \
  -DCMAKE_BUILD_TYPE=Debug -DGNODE_ENABLE_UNIT_TESTS=ON \
  -DGNODE_ENABLE_TESTS=OFF -DGNODE_ENABLE_EXAMPLES=OFF \
  -DFETCHCONTENT_SOURCE_DIR_GOOGLETEST="$PWD/output/validation/googletest" \
  '-DCMAKE_CXX_FLAGS=-fsanitize=address,undefined -fno-omit-frame-pointer' \
  '-DCMAKE_EXE_LINKER_FLAGS=-fsanitize=address,undefined'
cmake --build build/gnode-sanitizers --parallel 2 --target gnode_unit_tests
ulimit -c 0
ASAN_OPTIONS=detect_leaks=0:halt_on_error=1:abort_on_error=1:detect_stack_use_after_return=1:fast_unwind_on_malloc=0 \
UBSAN_OPTIONS=print_stacktrace=1:halt_on_error=1 OMP_NUM_THREADS=1 \
  timeout 120 build/gnode-sanitizers/bin/gnode_unit_tests \
  --gtest_filter=ParallelGraphUpdate.GraphWorkerHoldAndResume --gtest_repeat=20
