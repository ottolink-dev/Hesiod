#!/usr/bin/env python3
"""Independently verify the selected 2048/4096 records and their derived report."""
from collections import Counter, defaultdict
import gzip
import hashlib
import json
from pathlib import Path
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT / 'docs/profiling/assessments/2026-11-27'
sys.path.insert(0, str(ROOT / 'scripts/profiling'))
from memory_study import jobs_for, run_name, summarize


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    full_path = BASE / 'comparisons/quilting-2048-4096.json.gz'
    full = json.loads(gzip.decompress(full_path.read_bytes()))
    compact = json.loads((BASE / 'comparisons/quilting-2048-4096-report.json').read_text())
    assert compact == {k: v for k, v in full.items() if k != 'results'}
    config, results, verification = full['config'], full['results'], full['verification']
    expected_names = {run_name(job) for job in jobs_for(config)}
    names = [run_name(row) for row in results]
    assert len(names) == len(set(names)) == len(expected_names) == 240
    assert set(names) == expected_names
    assert Counter(row['size'] for row in results) == {2048: 120, 4096: 120}
    assert all(row['status'] == 'ok' and row['failure_kind'] is None and row['app_exit'] == 0 for row in results)
    assert summarize(config, results) == full['report']
    assert full['report']['complete'] and full['report']['memory_scaling_check'] == 'pass'
    assert len(full['report']['comparisons']) == 40
    hashes = {Path(item['path']).parent.name: item['sha256'] for item in verification['source_result_files']}
    provenance = {}
    fixtures = defaultdict(set)
    settings = set()
    policy_checks = 0
    for series, source_config in verification['source_configs'].items():
        source = BASE / series
        assert json.loads((source / 'config.json').read_text()) == source_config
        assert source_config['threads'] == config['threads'] == 1
        assert source_config['repeats'] == config['repeats'] == 3
        provenance[series] = json.loads((source / 'provenance.json').read_text())
        raw = gzip.decompress((source / 'results.json.gz').read_bytes())
        assert digest(raw) == hashes[series]
        originals = {run_name(row): row for row in json.loads(raw)}
        selected = [row for row in results if row['source_series'] == series]
        with tarfile.open(source / 'run-evidence.tar.gz', 'r:gz') as archive:
            for row in selected:
                name = run_name(row)
                assert {k: v for k, v in row.items() if k not in ('source_series', 'source_result')} == originals[name]
                assert Path(row['source_result']).parts[-3:] == ('runs', name, 'result.json')
                prefix = f'runs/{name}'
                fixture = archive.extractfile(f'{prefix}/fixture.hsd').read()
                assert digest(fixture) == row['graph_sha256']
                fixtures[(row['case'], row['variant'], row['inputs_only'])].add(fixture)
                settings.add(archive.extractfile(f'{prefix}/config/hesiod/hesiod.json').read())
                log = archive.extractfile(f'{prefix}/app.log').read().decode(errors='replace')
                if row['policy'] == 'ram-sequential':
                    assert 'forcing sequential computation for all compute modes (CPU and GPU)' in log
                    flag = '--force-sequential'
                else:
                    assert 'minimal memory mode enabled (storage mode: VA_DISK_LRU_STREAM' in log
                    flag = '--min-memory'
                assert flag in row['command']
                assert f"--shape={row['size']},{row['size']}" in row['command']
                assert f"--tiling={row['tiles']},{row['tiles']}" in row['command']
                assert '--overlap=0' in row['command']
                policy_checks += 1
    assert all(len(variants) == 1 for variants in fixtures.values())
    assert len(settings) == 1
    assert json.loads(next(iter(settings)))['app_settings']['global.omp_num_threads'] == 1
    reference = provenance['memory-4096-quilting']
    for other in provenance.values():
        for field in verification['identical_provenance_fields']:
            assert other[field] == reference[field], field
        for policy, value in other['runtime_policy'].items():
            assert reference['runtime_policy'][policy] == value
    native = json.loads((BASE / 'memory-4096-quilting/report.json').read_text())
    text = (BASE / 'README.md').read_text()
    table = {}
    for case in ('TextureQuiltingShuffle', 'TextureQuiltingExpand', 'Abs'):
        values = []
        for policy, tiles in [('ram-sequential', 1), ('ram-sequential', 4), ('disk-sequential', 1), ('disk-sequential', 4)]:
            cell, = [row for row in native['cells'] if row['case'] == case and row['variant'] == 'full'
                     and not row['inputs_only'] and row['policy'] == policy and row['tiles'] == tiles]
            values.append(f"{cell['process_peak_mib_median']:,.1f}")
        assert '| ' + ' | '.join([case, *values]) + ' |' in text
        table[case] = values
    status = json.loads((BASE / 'memory-4096-quilting/status.json').read_text())
    assert status['completed_runs'] == status['planned_runs'] == 120
    assert f"{status['elapsed_seconds']/60:.2f} minutes" in text
    evidence = {'derived_archive_sha256': digest(full_path.read_bytes()), 'unique_selected_runs': 240,
                'reused_2048_runs': 120, 'new_4096_runs': 120, 'comparison_count': 40,
                'report_regenerated_exactly': True, 'all_source_record_fields_equal': True,
                'selected_fixture_hashes_verified': 240, 'fixture_groups_identical': len(fixtures),
                'selected_policy_logs_verified': policy_checks, 'identical_isolated_settings': True,
                'source_result_hashes': hashes, 'identical_provenance_fields': verification['identical_provenance_fields'],
                'table_verified': table, 'native_workloads_started': 0}
    output = ROOT / 'output/validation/derived-4096-quilting-review.json'
    output.write_text(json.dumps(evidence, indent=2) + '\n')
    print(json.dumps(evidence))


if __name__ == '__main__':
    main()
