#!/usr/bin/env python3
"""Read-only policy audit for finished memory-study series; writes one audit JSON."""
import json
from pathlib import Path
import re
import sys

MARKERS = {
    'ram-sequential': ('--force-sequential', 'forcing sequential computation for all compute modes (CPU and GPU)'),
    'disk-sequential': ('--min-memory', 'minimal memory mode enabled (storage mode: VA_DISK_LRU_STREAM, compute mode: VA_SEQUENTIAL)'),
}

for name in sys.argv[1:]:
    root = Path(name).resolve()
    config = json.loads((root / 'config.json').read_text())
    state = json.loads((root / 'status.json').read_text())
    results = json.loads((root / 'results.json').read_text())
    checks = []
    for row in results:
        command = row['command']
        graph = Path(next(a.removeprefix('--batch=') for a in command if a.startswith('--batch=')))
        folder = graph.parent
        log = (folder / 'app.log').read_text(errors='replace')
        settings = json.loads((folder / 'config/hesiod/hesiod.json').read_text())
        own_flag, own_marker = MARKERS[row['policy']]
        checks.append({
            'run': folder.name,
            'intended_policy': row['policy'],
            'correct_policy_marker': own_marker in log,
            'no_conflicting_policy_marker': all(marker not in log for policy, (_, marker) in MARKERS.items() if policy != row['policy']),
            'correct_policy_flag': own_flag in command,
            'no_conflicting_policy_flag': all(flag not in command for policy, (flag, _) in MARKERS.items() if policy != row['policy']),
            'isolated_omp_setting_matches': settings['app_settings']['global.omp_num_threads'] == config['threads'],
            'observed_startup_openmp_max_threads': sorted(set(int(v) for v in re.findall(r'Max threads: (\d+)\s*$', log.split('executing Hesiod in batch mode', 1)[0], re.MULTILINE))),
            'no_ipc_flag': '--ipc' not in command,
            'successful_workload': row['status'] == 'ok' and row['app_exit'] == 0,
        })
    flags = ('correct_policy_marker', 'no_conflicting_policy_marker', 'correct_policy_flag',
             'no_conflicting_policy_flag', 'isolated_omp_setting_matches', 'no_ipc_flag', 'successful_workload')
    failures = [row for row in checks if not all(row[key] for key in flags) or row['observed_startup_openmp_max_threads'] != [config['threads']]]
    audit = {
        'source': str(root),
        'method': 'Read every result command, app log and per-run isolated hesiod.json; require intended sequential-policy marker and flag, no conflicting policy, configured OpenMP thread count and startup max-thread log before concurrent graph workers start (worker trace lines can interleave), no IPC flag and successful workload exit.',
        'planned_runs': state['planned_runs'], 'audited_runs': len(checks),
        'complete': state['state'] == 'finished' and len(checks) == state['planned_runs'],
        'failure_count': len(failures), 'failures': failures,
        'policy_counts': {policy: sum(c['intended_policy'] == policy for c in checks) for policy in MARKERS},
        'checks': checks,
    }
    audit['passed'] = audit['complete'] and not failures
    target = Path('output/validation') / (root.name + '-policy-audit.json')
    target.write_text(json.dumps(audit, indent=2) + '\n')
    print(root.name, {k: audit[k] for k in ('audited_runs', 'complete', 'failure_count', 'passed')})
    if not audit['passed']:
        raise SystemExit(2)
