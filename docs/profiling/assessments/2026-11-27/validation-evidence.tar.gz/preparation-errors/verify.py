#!/usr/bin/env python3
"""Isolated regression checks; never modify measured or live runner sources."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
rows = []
for label, source in [('current', ROOT), ('frozen-ram', ROOT / 'output/memory-ram')]:
    copied = OUT / label
    copied.mkdir()
    for package in ('profiling', 'hsd'):
        shutil.copytree(source / 'scripts' / package, copied / 'scripts' / package,
                        ignore=shutil.ignore_patterns('__pycache__'))
    runner = copied / 'scripts/profiling/memory_study.py'
    for scenario in ('invalid-fixture', 'prepare-oserror', 'prepare-runtimeerror'):
        case = copied / scenario
        (case / 'bin/data').mkdir(parents=True)
        catalog = json.loads((ROOT / 'Hesiod/data/node_documentation.json').read_text())
        if scenario == 'invalid-fixture':
            del catalog['Abs']['ports']['input']
        (case / 'bin/data/node_documentation.json').write_text(json.dumps(catalog))
        binary = case / 'bin/hesiod'
        marker = case / 'unexpected-binary-launch'
        binary.write_text(f'#!{sys.executable}\nfrom pathlib import Path\nPath({str(marker)!r}).touch()\n')
        binary.chmod(0o755)
        output = case / 'study'
        args = ['run', '--binary', str(binary), '--output', str(output), '--cases', 'Abs',
                '--sizes', '64', '128', '--tiles', '1', '--overlaps', '0', '--repeats', '1',
                '--check-min-size', '64', '--check']
        if scenario == 'invalid-fixture':
            command = [sys.executable, str(runner), *args]
        else:
            exception = 'OSError' if scenario == 'prepare-oserror' else 'RuntimeError'
            driver = case / 'invoke.py'
            driver.write_text('import sys\nfrom unittest.mock import patch\n'
                f'sys.path.insert(0, {str(runner.parent)!r})\nimport memory_study\n'
                f'with patch.object(memory_study, "prepare_run", side_effect={exception}("injected preparation failure")):\n'
                '    sys.exit(memory_study.main(sys.argv[1:]))\n')
            command = [sys.executable, str(driver), *args]
        completed = subprocess.run(command, text=True, capture_output=True, timeout=30)
        (case / 'stdout.log').write_text(completed.stdout)
        (case / 'stderr.log').write_text(completed.stderr)
        status = json.loads((output / 'status.json').read_text())
        report = json.loads((output / 'report.json').read_text())
        assert completed.returncode != 0, (label, scenario, completed.returncode)
        assert status['state'] == 'failed', status
        assert status['completed_runs'] == 0 and 'current' not in status, status
        assert not report['complete'] and report['memory_scaling_check'] == 'incomplete', report
        assert not marker.exists(), marker
        assert not list((output / 'runs').rglob('result.json'))
        rows.append({'source': label, 'scenario': scenario, 'command': command,
                     'runner_sha256': hashlib.sha256(runner.read_bytes()).hexdigest(),
                     'exit_code': completed.returncode, 'status': status,
                     'report_complete': report['complete'],
                     'memory_scaling_check': report['memory_scaling_check'],
                     'binary_executed': marker.exists()})
(OUT / 'results.json').write_text(json.dumps(rows, indent=2) + '\n')
print(f'{len(rows)} isolated preparation-error regression checks passed')
