import sys
from unittest.mock import patch
sys.path.insert(0, '/home/barrulus/dev/Hesiod-783/output/validation/preparation-errors/frozen-ram/scripts/profiling')
import memory_study
with patch.object(memory_study, "prepare_run", side_effect=OSError("injected preparation failure")):
    sys.exit(memory_study.main(sys.argv[1:]))
