#!/usr/bin/env python3
"""Read-only five-second VmSwap observer for named memory-study series.

Only inspect a PID when its argv matches that series' frozen Hesiod and exact
current fixture. Samples do not establish the absence of brief swap activity.
"""
import argparse
import json
import os
from pathlib import Path
import signal
import sys
import time

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('series', nargs='+', type=Path)
parser.add_argument('--prefix', default='memory')
args = parser.parse_args()
roots = [p.resolve() for p in args.series]
output = Path('output/validation').resolve()
prefix = args.prefix
if not prefix or any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-' for c in prefix):
    parser.error('prefix must contain only letters, digits, hyphens or underscores')
pid_name = 'vmswap-observer.pid' if prefix == 'memory' else prefix + '-vmswap-observer.pid'
(output / pid_name).write_text(str(os.getpid()) + '\n')
observed = {}
stopping = False
started = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())


def stop(signum, frame):
    global stopping
    stopping = True


def save_summary(state):
    completed = {}
    for root in roots:
        results = root / 'results.json'
        if results.exists():
            try:
                completed[root.name] = len(json.loads(results.read_text()))
            except (OSError, ValueError):
                pass
    data = {'state': state, 'started_utc': started,
            'updated_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
            'sample_interval_seconds': 5, 'series': [str(p) for p in roots],
            'completed_results_seen': completed, 'sampled_run_count': len(observed),
            'runs_with_observed_swap': sum(r['max_observed_vm_swap_kib'] > 0 for r in observed.values()),
            'limitations': 'Sparse live-process VmSwap samples, not a kernel high-water mark. Fast runs, earlier runs and events between samples may be missed. Zero observed VmSwap does not prove no swapping. Global paging counters are shared-host data.',
            'runs': list(observed.values())}
    temporary = output / (prefix + '-vmswap-summary.json.tmp')
    temporary.write_text(json.dumps(data, indent=2) + '\n')
    temporary.replace(output / (prefix + '-vmswap-summary.json'))


signal.signal(signal.SIGTERM, stop)
signal.signal(signal.SIGINT, stop)
deadline = time.monotonic() + 8 * 3600
state = 'running'
with (output / (prefix + '-vmswap-samples.jsonl')).open('a') as stream:
    while not stopping and time.monotonic() < deadline:
        finished = []
        for root in roots:
            status_path = root / 'status.json'
            if not status_path.exists():
                finished.append(False)
                continue
            try:
                status = json.loads(status_path.read_text())
                finished.append(status['state'] != 'running')
                if status['state'] != 'running' or 'current' not in status:
                    continue
                folder = root / 'runs' / status['current']
                pid = int((folder / 'child.pid').read_text())
                proc = Path('/proc') / str(pid)
                argv = [x.decode() for x in (proc / 'cmdline').read_bytes().split(b'\0') if x]
                if not argv or argv[0] != str(root / 'bin/hesiod') or f'--batch={folder / "fixture.hsd"}' not in argv:
                    continue
                values = {}
                for line in (proc / 'status').read_text().splitlines():
                    key, _, value = line.partition(':')
                    if key in ('VmRSS', 'VmHWM', 'VmSwap'):
                        values[key] = int(value.split()[0])
                if 'VmSwap' not in values:
                    continue
                mem = {k: int(v.split()[0]) for k, v in
                       (line.split(':', 1) for line in Path('/proc/meminfo').read_text().splitlines())}
                vm = dict(line.split() for line in Path('/proc/vmstat').read_text().splitlines())
                when = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
                key = root.name + '/' + folder.name
                sample = {'time_utc': when, 'run': key, 'pid': pid,
                          'vm_swap_kib': values['VmSwap'], 'vm_rss_kib': values.get('VmRSS'),
                          'vm_hwm_kib': values.get('VmHWM'), 'host_mem_available_kib': mem['MemAvailable'],
                          'host_swap_free_kib': mem['SwapFree'],
                          'host_pswpin': int(vm['pswpin']), 'host_pswpout': int(vm['pswpout'])}
                stream.write(json.dumps(sample) + '\n')
                stream.flush()
                row = observed.setdefault(key, {'run': key, 'pid': pid, 'samples': 0,
                    'first_sample_utc': when, 'max_observed_vm_swap_kib': 0,
                    'max_observed_vm_rss_kib': 0, 'min_host_available_kib': mem['MemAvailable']})
                row.update(last_sample_utc=when, samples=row['samples'] + 1,
                    max_observed_vm_swap_kib=max(row['max_observed_vm_swap_kib'], values['VmSwap']),
                    max_observed_vm_rss_kib=max(row['max_observed_vm_rss_kib'], values.get('VmRSS', 0)),
                    min_host_available_kib=min(row['min_host_available_kib'], mem['MemAvailable']))
            except (OSError, ValueError, KeyError, IndexError):
                continue  # Process exited or metadata changed while being sampled.
        if finished and len(finished) == len(roots) and all(finished):
            state = 'finished'
            break
        save_summary('running')
        time.sleep(5)
    else:
        state = 'stopped' if stopping else 'time_budget_exhausted'
save_summary(state)
print(json.dumps({'state': state, 'sampled_run_count': len(observed)}))
