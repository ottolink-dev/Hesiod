#!/usr/bin/env python3
"""Derive comparisons by reusing completed lower-size runs, never rerun workloads."""
import argparse
import collections
import hashlib
import importlib.util
import json
from pathlib import Path
from statistics import median
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'scripts/profiling'))
import memory_study as study


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(name):
    folder = ROOT / 'output' / name
    config = json.loads((folder / 'config.json').read_text())
    provenance = json.loads((folder / 'provenance.json').read_text())
    state = json.loads((folder / 'status.json').read_text())
    rows = json.loads((folder / 'results.json').read_text())
    audit = json.loads((ROOT / 'output/validation' / f'{name}-policy-audit.json').read_text())
    assert state['state'] == 'finished' and len(rows) == state['planned_runs']
    assert audit['passed'], 'source series policy audit failed'
    assert all(r['status'] == 'ok' for r in rows), 'source series has failed workloads'
    for row in rows:
        row['source_series'] = name
        row['source_result'] = str(folder / 'runs' / study.run_name(row) / 'result.json')
    return {'config': config, 'provenance': provenance, 'rows': rows,
            'results_sha256': digest(folder / 'results.json'), 'path': str(folder)}


def verify(sources, rows):
    reference = sources[0]
    fields = ['binary_sha256', 'script_sha256', 'data_sha256',
              'environment_overrides', 'backend', 'graph_scheduling']
    for source in sources[1:]:
        for field in fields:
            assert source['provenance'][field] == reference['provenance'][field], field
        assert source['config']['threads'] == reference['config']['threads']
        assert source['config']['repeats'] == reference['config']['repeats']
    policies = collections.defaultdict(list)
    for source in sources:
        for policy, settings in source['provenance']['runtime_policy'].items():
            policies[policy].append(settings)
    assert all(all(s == settings[0] for s in settings) for settings in policies.values()), 'shared runtime policy mismatch'
    assert digest(ROOT / 'scripts/profiling/memory_study.py') == reference['provenance']['script_sha256']['scripts/profiling/memory_study.py']
    graphs = collections.defaultdict(set)
    for row in rows:
        graphs[row['case'], row['variant'], row['inputs_only']].add(row['graph_sha256'])
    assert all(len(values) == 1 for values in graphs.values()), 'fixture bytes differ across series'
    return {'binary_sha256': reference['provenance']['binary_sha256'],
            'identical_provenance_fields': fields, 'identical_settings_for_each_shared_policy': True, 'identical_threads': reference['config']['threads'],
            'identical_repeats': reference['config']['repeats'],
            'identical_fixture_bytes_per_case_variant_mode': True,
            'all_source_policy_audits_pass': True,
            'source_configs': {Path(s['path']).name: s['config'] for s in sources},
            'source_result_files': [{'path': s['path'] + '/results.json', 'sha256': s['results_sha256']} for s in sources],
            'caveat': 'Different size/grid CLI settings are explicit. Resource stop guards and timeouts differ; every selected run completed successfully. Wall times were measured on a shared host, not controlled performance tests.'}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('kind', choices=['quilting', 'export', 'fixed-core'])
    args = parser.parse_args()
    name = {'quilting': 'memory-4096-quilting', 'export': 'memory-4096-export', 'fixed-core': 'memory-4096-fixed-tiles'}[args.kind]
    upper = load(name)
    lowers = [load('memory-ram'), load('memory-disk')] if args.kind == 'quilting' else [load('memory-ram' if args.kind == 'export' else 'memory-disk')]
    config = dict(upper['config'], sizes=[2048, 4096])
    if args.kind != 'fixed-core':
        wanted = {study.run_name(job) for job in study.jobs_for(config)}
        rows = [r for s in [*lowers, upper] for r in s['rows'] if study.run_name(r) in wanted]
        verified = verify([*lowers, upper], rows)
        report = study.summarize(config, rows)
        assert len(rows) == len(wanted) and report['complete']
        assert len(report['comparisons']) == (40 if args.kind == 'quilting' else 2)
        output = {'kind': 'derived same-grid 2048-to-4096 comparisons', 'reuses_lower_size_runs': True,
                  'config': config, 'verification': verified, 'report': report, 'results': rows}
    else:
        lower = lowers[0]
        rows = [r for r in lower['rows'] if r['size'] == 2048 and r['tiles'] == 4 and r['overlap'] == 0 and r['case'] in config['cases'] and r['variant'] == 'full'] + upper['rows']
        verified = verify([lower, upper], rows)
        groups = collections.defaultdict(list)
        for row in rows:
            groups[row['case'], row['inputs_only'], row['size']].append(row)
        pairs = []
        for case in config['cases']:
            for inputs in [False, True]:
                low, high = (groups[case, inputs, size] for size in [2048, 4096])
                assert len(low) == len(high) == config['repeats']
                a, b = (median(r['process_peak_rss_kib'] / 1024 for r in group) for group in [low, high])
                pairs.append({'case': case, 'variant': 'full', 'inputs_only': inputs, 'policy': 'disk-sequential', 'overlap': 0,
                              'low_size': 2048, 'high_size': 4096, 'low_grid': [4, 4], 'high_grid': [8, 8],
                              'tile_core': [512, 512], 'low_repeats': len(low), 'high_repeats': len(high),
                              'low_peak_mib_median': a, 'high_peak_mib_median': b, 'process_peak_ratio': b / a,
                              'pixel_ratio': 4, 'total_tile_count_ratio': 4})
        assert len(pairs) == 6 and len(rows) == 36
        output = {'kind': 'derived changed-grid fixed-512x512-tile-core comparison', 'reuses_lower_size_runs': True,
                  'verification': verified, 'pairs': pairs, 'results': rows,
                  'limitations': 'Six descriptive paired medians, separate from same-grid growth guards. Whole-process RSS includes startup and concurrent graph sources, excludes filesystem page cache; constant tile core does not imply a constant total-RAM workload. Numerical output correctness is not assessed.'}
    target = ROOT / 'output/validation' / f'memory-2048-4096-{args.kind}-comparison.json'
    target.write_text(json.dumps(output, indent=2) + '\n')
    print(target)
    if args.kind != 'fixed-core':
        print('selected runs', len(rows), 'comparisons', len(report['comparisons']), 'check', report['memory_scaling_check'])
    else:
        for pair in pairs:
            print(pair['case'], 'inputs' if pair['inputs_only'] else 'target', pair['low_peak_mib_median'], pair['high_peak_mib_median'], pair['process_peak_ratio'])

if __name__ == '__main__':
    main()
