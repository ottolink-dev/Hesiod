#!/usr/bin/env bash
set -u
repo=/home/barrulus/dev/Hesiod-783
export QT_QPA_PLATFORM=offscreen
export OMP_NUM_THREADS=1
export XDG_CONFIG_HOME="$repo/output/validation/xdg-config"
export XDG_CACHE_HOME="$repo/output/validation/xdg-cache"
cd "$repo/build/assessment/bin"
for target in gnode_unit_tests meta_unittests clwrapper_unit_tests highmap_tests; do
  timeout 1800 "./$target" --gtest_brief=1 --gtest_output="json:$repo/output/validation/$target.json" > "$repo/output/validation/$target.log" 2>&1
  printf '%s\n' "$?" > "$repo/output/validation/$target.exit"
done
/nix/store/bi3mnvps3yr4ir0jbd5vikqc4vra76xv-valgrind-3.27.1/bin/valgrind --tool=memcheck --error-exitcode=99 --leak-check=full --show-leak-kinds=definite --errors-for-leak-kinds=definite --log-file="$repo/output/validation/profile-highmap-valgrind.log" ./profile_highmap > "$repo/output/validation/profile-highmap-valgrind.stdout" 2>&1
printf '%s\n' "$?" > "$repo/output/validation/profile-highmap-valgrind.exit"
