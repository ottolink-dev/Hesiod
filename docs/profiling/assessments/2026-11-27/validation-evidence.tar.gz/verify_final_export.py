#!/usr/bin/env python3
"""Final incremental export/aggregate/docs verification; no native execution."""
from collections import Counter, defaultdict
import gzip
import hashlib
import json
from pathlib import Path
import re
import shlex
from statistics import median
import sys
import tarfile
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT / 'docs/profiling/assessments/2026-11-27'
VALIDATION = ROOT / 'output/validation'
sys.path.insert(0, str(ROOT / 'scripts/profiling'))
import memory_study

def read(name):
    return json.loads((BASE / name).read_text())

def results(series):
    return json.loads(gzip.decompress((BASE / series / 'results.json.gz').read_bytes()))

def sha(data):
    return hashlib.sha256(data).hexdigest()

def main():
    derived = json.loads(gzip.decompress((BASE / 'comparisons/export-2048-4096.json.gz').read_bytes()))
    assert read('comparisons/export-2048-4096-report.json') == {k: v for k, v in derived.items() if k != 'results'}
    rows = derived['results']
    assert len(rows) == len({memory_study.run_name(r) for r in rows}) == 12
    assert Counter(r['size'] for r in rows) == {2048: 6, 4096: 6}
    assert {memory_study.run_name(r) for r in rows} == {memory_study.run_name(j) for j in memory_study.jobs_for(derived['config'])}
    assert memory_study.summarize(derived['config'], rows) == derived['report']
    assert derived['report']['complete'] and derived['report']['memory_scaling_check'] == 'pass'
    assert len(derived['report']['comparisons']) == 2
    check = derived['verification']
    sources = {Path(item['path']).parent.name: item['sha256'] for item in check['source_result_files']}
    provenance, fixtures, settings = {}, defaultdict(set), set()
    for series, expected_config in check['source_configs'].items():
        assert read(f'{series}/config.json') == expected_config
        assert expected_config['threads'] == 1 and expected_config['repeats'] == 3
        provenance[series] = read(f'{series}/provenance.json')
        raw = gzip.decompress((BASE / series / 'results.json.gz').read_bytes())
        assert sha(raw) == sources[series]
        originals = {memory_study.run_name(r): r for r in json.loads(raw)}
        with tarfile.open(BASE / series / 'run-evidence.tar.gz') as archive:
            for row in [r for r in rows if r['source_series'] == series]:
                name = memory_study.run_name(row)
                assert {k: v for k, v in row.items() if k not in ('source_series', 'source_result')} == originals[name]
                fixture = archive.extractfile(f'runs/{name}/fixture.hsd').read()
                assert sha(fixture) == row['graph_sha256']
                fixtures[row['variant']].add(fixture)
                settings.add(archive.extractfile(f'runs/{name}/config/hesiod/hesiod.json').read())
                log = archive.extractfile(f'runs/{name}/app.log').read().decode(errors='replace')
                assert 'forcing sequential computation for all compute modes (CPU and GPU)' in log
                assert 'minimal memory mode enabled' not in log
                assert '--force-sequential' in row['command'] and '--tiling=1,1' in row['command'] and '--overlap=0' in row['command']
                assert f"--shape={row['size']},{row['size']}" in row['command']
    assert all(len(values) == 1 for values in fixtures.values()) and len(settings) == 1
    assert json.loads(next(iter(settings)))['app_settings']['global.omp_num_threads'] == 1
    low, high = provenance.values()
    for field in check['identical_provenance_fields']:
        assert low[field] == high[field]
    assert low['runtime_policy']['ram-sequential'] == high['runtime_policy']['ram-sequential']
    text = (BASE / 'README.md').read_text()
    table = {}
    for variant in ('minimal', 'full'):
        values = [median(r['process_peak_rss_kib'] / 1024 for r in rows if r['variant'] == variant and r['size'] == size)
                  for size in (2048, 4096)]
        ratio = values[1] / values[0]
        assert f'| {variant.title()} | {values[0]:,.1f} | {values[1]:,.1f} | {ratio:.3f}× |' in text
        table[variant] = {'low_median': values[0], 'high_median': values[1], 'ratio': ratio}
    full_runs = [r for r in rows if r['variant'] == 'full' and r['size'] == 4096]
    peak_range = [min(r['process_peak_rss_kib'] / 1024 for r in full_runs), max(r['process_peak_rss_kib'] / 1024 for r in full_runs)]
    assert f'{peak_range[0]:,.1f}–{peak_range[1]:,.1f} MiB' in text
    wall_minutes = [r['wall_seconds']/60 for r in full_runs]
    assert all(26 <= minutes <= 27 for minutes in wall_minutes)
    status = read('memory-4096-export/status.json')
    assert status['completed_runs'] == status['planned_runs'] == 6
    assert f"{status['elapsed_seconds']/60:.2f} minutes" in text
    config = read('memory-4096-export/config.json')
    assert config['timeout'] == 2400 and config['max_rss_mib'] == 16384
    primary = ['memory-ram', 'memory-disk', 'memory-4096-quilting', 'memory-4096-fixed-tiles', 'memory-4096-export']
    all_results = [r for series in primary for r in results(series)]
    assert len(all_results) == len({memory_study.run_name(r) for r in all_results}) == 900
    assert all(r['status'] == 'ok' for r in all_results)
    comparisons = [*read('memory-ram/report.json')['comparisons'], *read('memory-disk/report.json')['comparisons'],
                   *read('comparisons/quilting-2048-4096-report.json')['report']['comparisons'], *derived['report']['comparisons']]
    assert len(comparisons) == 210 and all(c['status'] == 'pass' for c in comparisons)
    for series in primary:
        audit = json.loads((VALIDATION / f'{series}-policy-audit.json').read_text())
        assert audit['passed'] and audit['audited_runs'] == len(results(series)) and audit['failure_count'] == 0
    groups = defaultdict(list)
    for r in all_results:
        if r['case'] == 'ExportAsset' and not r['inputs_only']:
            groups[(r['size'], r['variant'], r['tiles'], r['overlap'])].append(r)
    assert len(groups) == 20 and sum(map(len, groups.values())) == 114
    for key, group in groups.items():
        assert len(group) == (3 if key[0] == 4096 else 6)
        assert len({tuple(sorted((a['path'], a['bytes'], a['sha256']) for a in r['artifacts'])) for r in group}) == 1
    observers = {}
    for prefix, expected in [('memory', 99), ('fixed-tiles', 13)]:
        summary = json.loads((VALIDATION / f'{prefix}-vmswap-summary.json').read_text())
        samples = [json.loads(line) for line in (VALIDATION / f'{prefix}-vmswap-samples.jsonl').read_text().splitlines()]
        assert len({r['run'] for r in samples}) == summary['sampled_run_count'] == expected
        assert all(r['vm_swap_kib'] == 0 for r in samples)
        assert summary['runs_with_observed_swap'] == 0
        observers[prefix] = {'runs': expected, 'samples': len(samples), 'observed_swapped_runs': 0}
    methods = (ROOT / 'docs/profiling/memory-assessment/README.md').read_text().replace('\\\n', '')
    commands = re.findall(r'^python3 scripts/profiling/memory_study.py run .*$', methods, flags=re.M)
    command_checks = []
    for command in commands:
        captured = []
        with patch.object(memory_study, 'run', side_effect=lambda args: captured.append(vars(args)) or 0):
            assert memory_study.main(shlex.split(command)[2:]) == 0
        args, = captured
        series = args['output'].name
        if series == 'memory-smoke':
            series = 'memory-smoke-64-v3'
        parsed_config = {k: v for k, v in args.items() if k not in ('command', 'output', 'binary')}
        expected = read(f'{series}/config.json')
        differences = {k: [expected[k], v] for k, v in parsed_config.items() if expected[k] != v}
        assert not differences, (series, differences)
        command_checks.append({'series': series, 'command': command, 'config_exact': True})
    evidence = {'derived_export_runs': 12, 'reused_export_runs': 6, 'new_export_runs': 6, 'export_guards': 2,
                'fixture_provenance_settings_verified': True, 'table': table, 'full_peak_range_mib': peak_range,
                'full_wall_minutes': wall_minutes, 'export_elapsed_minutes': status['elapsed_seconds']/60,
                'primary_runs': 900, 'same_grid_guards': 210, 'policy_audited_runs': 900,
                'repeatable_export_runs': 114, 'repeatability_configurations': 20, 'observers': observers,
                'methods_commands': command_checks, 'native_workloads_started': 0}
    (VALIDATION / 'final-export-and-aggregate-review.json').write_text(json.dumps(evidence, indent=2) + '\n')
    print('Export archive/derived evidence, 900 runs, 210 guards, 114 repeatability records, observers and methods verified')

if __name__ == '__main__':
    main()
