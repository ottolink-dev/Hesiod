#!/usr/bin/env python3
"""Compare recorded export hashes across repeats/policies within each layout.

This reads existing result manifests; it does not rehash export files or claim
numerical correctness, and it never equates outputs from different tile layouts.
"""
import argparse
import collections
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'scripts/profiling'))
from memory_study import jobs_for

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('series', type=Path, nargs='+')
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
expected = collections.Counter()
policies = collections.defaultdict(collections.Counter)
actual = collections.defaultdict(list)


def key(row):
    return (row['size'], row['variant'], row['tiles'], row['overlap'])


for root in args.series:
    config = json.loads((root / 'config.json').read_text())
    for job in jobs_for(config):
        if job['case'] == 'ExportAsset' and not job['inputs_only']:
            expected[key(job)] += 1
            policies[key(job)][job['policy']] += 1
    for row in json.loads((root / 'results.json').read_text()):
        if row['case'] == 'ExportAsset' and not row['inputs_only']:
            actual[key(row)].append(row)
checks = []
for group in sorted(set(expected) | set(actual)):
    rows = actual[group]
    good = [r for r in rows if r['status'] == 'ok' and r.get('artifacts')]
    signatures = {tuple(sorted((a['path'], a['sha256']) for a in r['artifacts'])) for r in good}
    observed_policies = collections.Counter(r['policy'] for r in good)
    checks.append(dict(zip(('size', 'variant', 'tiles', 'overlap'), group),
        planned_runs=expected[group], successful_runs=len(good),
        planned_policy_counts=dict(policies[group]), observed_policy_counts=dict(observed_policies),
        distinct_artifact_sets=len(signatures),
        identical=(len(good) == len(rows) == expected[group] and
                   observed_policies == policies[group] and len(signatures) == 1)))
audit = {'scope': __doc__.strip(), 'sources': [str(p) for p in args.series],
         'configuration_cells': len(checks),
         'compared_runs': sum(c['successful_runs'] for c in checks),
         'all_identical': bool(checks) and all(c['identical'] for c in checks), 'checks': checks}
args.output.write_text(json.dumps(audit, indent=2) + '\n')
print({k: audit[k] for k in ('configuration_cells', 'compared_runs', 'all_identical')})
raise SystemExit(0 if audit['all_identical'] else 2)
