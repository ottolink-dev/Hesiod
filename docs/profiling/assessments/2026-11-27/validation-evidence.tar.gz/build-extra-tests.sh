#!/usr/bin/env bash
set -euo pipefail
cd /home/barrulus/dev/Hesiod-783
export QT_QPA_PLATFORM=offscreen
cmake -S . -B build/assessment \
 -DCMAKE_PROJECT_highmap-root_INCLUDE="$PWD/output/validation/enable-highmap-tests.cmake" \
 -DCMAKE_PROJECT_meta-root_INCLUDE="$PWD/output/validation/enable-meta-tests.cmake" \
 -DFETCHCONTENT_SOURCE_DIR_GOOGLETEST="$PWD/output/validation/googletest" \
 -DGNODE_ENABLE_UNIT_TESTS=ON -DCLWRAPPER_ENABLE_TESTS=ON \
 > output/validation/configure-extra-tests.log 2>&1
cmake --build build/assessment --parallel 8 --target highmap_tests gnode_unit_tests meta_unittests clwrapper_unit_tests > output/validation/build-extra-tests.log 2>&1
