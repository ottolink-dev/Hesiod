#!/usr/bin/env python3
"""Local orchestration only; committed measurement scripts remain unchanged."""
import datetime
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'output'
VALIDATION = OUT / 'validation'

def timestamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def preflight(phase):
    mem = {line.split(':')[0]: int(line.split()[1]) for line in Path('/proc/meminfo').read_text().splitlines()}
    vm = dict(line.split() for line in Path('/proc/vmstat').read_text().splitlines())
    row = {'timestamp': timestamp(), 'phase': phase, 'meminfo_kib': {k: mem[k] for k in ['MemAvailable', 'SwapTotal', 'SwapFree']}, 'pswpin': int(vm['pswpin']), 'pswpout': int(vm['pswpout']), 'disk_free_bytes': shutil.disk_usage(ROOT).free}
    with (VALIDATION / 'memory-host-resources.jsonl').open('a') as out:
        out.write(json.dumps(row) + '\n')
    if mem['MemAvailable'] < 30 * 1024**2:
        raise RuntimeError('less than 30 GiB MemAvailable at phase preflight')
    if row['disk_free_bytes'] < 40 * 1024**3:
        raise RuntimeError('less than 40 GiB workspace disk free at phase preflight')
    print(json.dumps(row), flush=True)

def run(phase, options):
    preflight(phase)
    command = [sys.executable, 'scripts/profiling/memory_study.py', 'run', '--binary', 'build/assessment/bin/hesiod', '--output', f'output/{phase}', *options]
    print(timestamp(), 'launch', command, flush=True)
    with (VALIDATION / f'{phase}.log').open('w') as log:
        subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, check=True)
    subprocess.run([sys.executable, 'output/validation/audit_memory_policy.py', f'output/{phase}'], cwd=ROOT, check=True)
    print(timestamp(), 'complete', phase, flush=True)

while True:
    status = json.loads((OUT / 'memory-4096-quilting/status.json').read_text())
    if status['state'] != 'running':
        if status['completed_runs'] != status['planned_runs']:
            raise RuntimeError(f'quilting phase unfinished: {status}')
        results = json.loads((OUT / 'memory-4096-quilting/results.json').read_text())
        if any(row['status'] != 'ok' for row in results):
            raise RuntimeError('quilting phase contains failed runs')
        break
    time.sleep(5)
subprocess.run([sys.executable, 'output/validation/audit_memory_policy.py', 'output/memory-4096-quilting'], cwd=ROOT, check=True)
run('memory-4096-fixed-tiles', ['--cases', 'TextureQuiltingShuffle', 'TextureQuiltingExpand', 'Abs', '--sizes', '4096', '--tiles', '8', '--overlaps', '0', '--variants', 'full', '--policies', 'disk-sequential', '--include-inputs', '--repeats', '3', '--timeout', '600', '--max-rss-mib', '12288', '--max-disk-gib', '32'])
run('memory-4096-export', ['--cases', 'ExportAsset', '--sizes', '4096', '--tiles', '1', '--overlaps', '0', '--variants', 'minimal', 'full', '--policies', 'ram-sequential', '--repeats', '3', '--timeout', '2400', '--max-rss-mib', '16384', '--max-disk-gib', '32'])
