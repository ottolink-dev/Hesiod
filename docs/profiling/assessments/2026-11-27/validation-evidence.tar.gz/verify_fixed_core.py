#!/usr/bin/env python3
"""Verify archived fixed-core selection, evidence and independently rebuilt medians."""
from collections import Counter, defaultdict
import gzip
import hashlib
import itertools
import json
from pathlib import Path
from statistics import median
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT / 'docs/profiling/assessments/2026-11-27'
sys.path.insert(0, str(ROOT / 'scripts/profiling'))
from memory_study import run_name

def main():
    archive_path = BASE / 'comparisons/fixed-core-2048-4096.json.gz'
    full = json.loads(gzip.decompress(archive_path.read_bytes()))
    compact = json.loads((BASE / 'comparisons/fixed-core-2048-4096-report.json').read_text())
    assert compact == {k: v for k, v in full.items() if k != 'results'}
    rows, check = full['results'], full['verification']
    cases = ['TextureQuiltingShuffle', 'TextureQuiltingExpand', 'Abs']
    assert len(rows) == len({run_name(row) for row in rows}) == 36
    assert Counter(row['size'] for row in rows) == {2048: 18, 4096: 18}
    identities = {(r['case'], r['inputs_only'], r['size'], r['repeat']) for r in rows}
    assert identities == set(itertools.product(cases, [False, True], [2048, 4096], [1, 2, 3]))
    for row in rows:
        assert row['policy'] == 'disk-sequential' and row['variant'] == 'full' and row['overlap'] == 0
        assert row['size'] / row['tiles'] == 512
        assert row['status'] == 'ok' and row['app_exit'] == 0 and row['failure_kind'] is None
    configs, provenances, fixtures, settings = {}, {}, defaultdict(set), set()
    source_hashes = {Path(item['path']).parent.name: item['sha256'] for item in check['source_result_files']}
    for series, claimed_config in check['source_configs'].items():
        source = BASE / series
        configs[series] = json.loads((source / 'config.json').read_text())
        assert configs[series] == claimed_config
        assert claimed_config['threads'] == 1 and claimed_config['repeats'] == 3
        provenances[series] = json.loads((source / 'provenance.json').read_text())
        raw = gzip.decompress((source / 'results.json.gz').read_bytes())
        assert hashlib.sha256(raw).hexdigest() == source_hashes[series]
        originals = {run_name(row): row for row in json.loads(raw)}
        with tarfile.open(source / 'run-evidence.tar.gz') as archive:
            for row in [r for r in rows if r['source_series'] == series]:
                name = run_name(row)
                assert {k: v for k, v in row.items() if k not in ('source_series', 'source_result')} == originals[name]
                assert Path(row['source_result']).parts[-3:] == ('runs', name, 'result.json')
                fixture = archive.extractfile(f'runs/{name}/fixture.hsd').read()
                assert hashlib.sha256(fixture).hexdigest() == row['graph_sha256']
                fixtures[(row['case'], row['inputs_only'])].add(fixture)
                settings.add(archive.extractfile(f'runs/{name}/config/hesiod/hesiod.json').read())
                log = archive.extractfile(f'runs/{name}/app.log').read().decode(errors='replace')
                assert 'minimal memory mode enabled (storage mode: VA_DISK_LRU_STREAM' in log
                assert '--min-memory' in row['command'] and '--overlap=0' in row['command']
                assert f"--shape={row['size']},{row['size']}" in row['command']
                assert f"--tiling={row['tiles']},{row['tiles']}" in row['command']
    assert all(len(group) == 1 for group in fixtures.values()) and len(settings) == 1
    assert json.loads(next(iter(settings)))['app_settings']['global.omp_num_threads'] == 1
    low, high = provenances.values()
    for field in check['identical_provenance_fields']:
        assert low[field] == high[field]
    assert low['runtime_policy']['disk-sequential'] == high['runtime_policy']['disk-sequential']
    pairs = []
    text = (BASE / 'README.md').read_text()
    for case, inputs in itertools.product(cases, [False, True]):
        medians = [median(r['process_peak_rss_kib'] / 1024 for r in rows
                          if r['case'] == case and r['inputs_only'] == inputs and r['size'] == size)
                   for size in (2048, 4096)]
        pair = dict(case=case, variant='full', inputs_only=inputs, policy='disk-sequential', overlap=0,
                    low_size=2048, high_size=4096, low_grid=[4, 4], high_grid=[8, 8], tile_core=[512, 512],
                    low_repeats=3, high_repeats=3, low_peak_mib_median=medians[0], high_peak_mib_median=medians[1],
                    process_peak_ratio=medians[1]/medians[0], pixel_ratio=4, total_tile_count_ratio=4)
        pairs.append(pair)
        role = 'Sources only' if inputs else 'Target and sources'
        assert f"| {case} | {role} | {medians[0]:,.1f} | {medians[1]:,.1f} | {pair['process_peak_ratio']:.3f}× |" in text
    assert pairs == full['pairs']
    assert 'Six descriptive paired medians, separate from same-grid growth guards' in full['limitations']
    native = json.loads((BASE / 'memory-4096-fixed-tiles/report.json').read_text())
    assert native['comparisons'] == [] and native['memory_scaling_check'] == 'incomplete'
    status = json.loads((BASE / 'memory-4096-fixed-tiles/status.json').read_text())
    assert status['completed_runs'] == status['planned_runs'] == 18
    assert f"{status['elapsed_seconds']/60:.2f} minutes" in text
    evidence = {'unique_selected_runs': 36, 'reused_2048_runs': 18, 'new_4096_runs': 18,
                'source_records_equal': True, 'fixture_hashes_verified': 36, 'fixture_groups_identical': 6,
                'provenance_fields_verified': check['identical_provenance_fields'], 'source_result_hashes': source_hashes,
                'settings_identical': True, 'core_dimensions': [512, 512], 'paired_medians_regenerated_exactly': pairs,
                'table_verified': True, 'separate_from_same_grid_guards': True, 'native_workloads_started': 0}
    (ROOT / 'output/validation/derived-fixed-core-review.json').write_text(json.dumps(evidence, indent=2) + '\n')
    print('36 original records, 6 paired medians/ratios and all table values verified')

if __name__ == '__main__':
    main()
