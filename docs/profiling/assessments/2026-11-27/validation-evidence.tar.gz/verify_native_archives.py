#!/usr/bin/env python3
"""Read-only archive verification. Accept one or more archived series directories."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parents[2]
ASSESSMENT = ROOT / 'docs/profiling/assessments/2026-11-27'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_series(source, scratch):
    destination = scratch / source.name
    destination.mkdir()
    archive = source / 'run-evidence.tar.gz'
    with tarfile.open(archive, 'r:gz') as stream:
        members = stream.getmembers()
        assert all(m.isfile() or m.isdir() for m in members), 'Unexpected archive link/device'
        stream.extractall(destination, filter='data')
    for name in ('config.json', 'provenance.json', 'status.json'):
        shutil.copy2(source / name, destination / name)
    with gzip.open(source / 'results.json.gz', 'rt') as stream:
        recorded_results = json.load(stream)
    actual_results = []
    measurement_count = 0
    for path in sorted((destination / 'runs').glob('*/result.json')):
        result = json.loads(path.read_text())
        assert digest(path.parent / 'fixture.hsd') == result['graph_sha256'], path
        measurement = path.parent / 'measurement.json'
        if measurement.exists():
            for key, value in json.loads(measurement.read_text()).items():
                assert result[key] == value, (path, key)
            measurement_count += 1
        actual_results.append(result)
    assert actual_results == recorded_results, 'Archived individual results differ from compressed results'
    provenance = json.loads((source / 'provenance.json').read_text())
    assert digest(destination / 'scripts/profiling/memory_study.py') == provenance['runner_sha256']
    for name, expected in provenance['script_sha256'].items():
        assert digest(destination / name) == expected, name
    assert digest(destination / 'source.diff') == provenance['source_diff_sha256']
    original_report = json.loads((source / 'report.json').read_text())
    regeneration = []
    for label, runner in [('archived', destination / 'scripts/profiling/memory_study.py'),
                          ('current', ROOT / 'scripts/profiling/memory_study.py')]:
        command = [sys.executable, str(runner), 'report', str(destination)]
        completed = subprocess.run(command, text=True, capture_output=True, timeout=30)
        assert completed.returncode == (0 if original_report['complete'] else 2), (command, completed.stderr)
        for name in ('report.json', 'report.csv'):
            assert (destination / name).read_bytes() == (source / name).read_bytes(), (label, source.name, name)
        assert json.loads((destination / 'results.json').read_text()) == recorded_results
        regeneration.append({'tooling': label, 'command': command, 'exit': completed.returncode,
                             'reports_byte_identical': True})
    status = json.loads((source / 'status.json').read_text())
    assert status['completed_runs'] == len(actual_results)
    return {'series': source.name, 'archive_sha256': digest(archive), 'archive_members': len(members),
            'run_results': len(actual_results), 'fixture_hashes_verified': len(actual_results),
            'measurements_verified': measurement_count, 'script_hashes_verified': len(provenance['script_sha256']),
            'complete': original_report['complete'], 'scaling_check': original_report['memory_scaling_check'],
            'cell_count': len(original_report['cells']), 'comparison_count': len(original_report['comparisons']),
            'status': status, 'regeneration': regeneration}


def verify_links(allow_pending=()):
    files = sorted(ASSESSMENT.rglob('*.md')) + sorted((ROOT / 'docs/profiling/memory-assessment').glob('*.md'))
    links = []
    for document in files:
        prose = re.sub(r'```.*?```', '', document.read_text(), flags=re.S)
        prose = re.sub(r'`[^`]*`', '', prose)
        for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^\s)]+)(?:\s+"[^"]*")?\)', prose):
            if re.match(r'\w+://|mailto:|#', target):
                continue
            target = unquote(target.split('#', 1)[0].strip('<>'))
            resolved = (document.parent / target).resolve()
            pending = resolved in {(ASSESSMENT / name).resolve() for name in allow_pending}
            assert resolved.exists() or pending, (document, target)
            links.append({'document': str(document.relative_to(ROOT)), 'target': target,
                          'pending': pending and not resolved.exists()})
    return links


def verify_disk_table():
    readme = (ASSESSMENT / 'README.md').read_text()
    section = readme.split('## Native resident memory: disk-backed series', 1)[1].split('\n## ', 1)[0]
    reports = {policy: json.loads((ASSESSMENT / f'memory-{policy}/report.json').read_text())
               for policy in ('ram', 'disk')}
    checked = {}
    for case in ('ExportAsset', 'TextureQuiltingShuffle', 'TextureQuiltingExpand', 'Abs'):
        values = []
        for policy, tiles, overlap in [('ram', 1, 0), ('disk', 1, 0), ('ram', 4, 0), ('disk', 4, 0), ('disk', 4, .1)]:
            cell, = [c for c in reports[policy]['cells'] if c['case'] == case and c['variant'] == 'full'
                     and not c['inputs_only'] and c['size'] == 2048 and c['tiles'] == tiles and c['overlap'] == overlap]
            values.append(f"{cell['process_peak_mib_median']:,.1f}")
        row = '| ' + ' | '.join([case, *values]) + ' |'
        assert row in section, row
        checked[case] = values
    status = json.loads((ASSESSMENT / 'memory-disk/status.json').read_text())
    assert status['completed_runs'] == status['planned_runs'] == 378
    assert len(reports['disk']['cells']) == 126
    assert len(reports['disk']['comparisons']) == 84
    assert all(row['status'] == 'pass' for row in reports['disk']['comparisons'])
    assert f"{status['elapsed_seconds']/60:.2f} minutes" in section
    return checked


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('series', type=Path, nargs='+')
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--allow-pending-links', nargs='*', default=[])
    args = parser.parse_args()
    with tempfile.TemporaryDirectory(prefix='native-archive-check-', dir=ROOT / 'output/validation') as temporary:
        reports = [verify_series(source.resolve(), Path(temporary)) for source in args.series]
    result = {'series': reports, 'relative_file_links': verify_links(args.allow_pending_links), 'disk_table': verify_disk_table(),
              'native_workloads_started': 0, 'source_archives_modified': False}
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'verified_series': [row['series'] for row in reports],
                      'verified_runs': sum(row['run_results'] for row in reports),
                      'relative_file_links': len(result['relative_file_links']),
                      'output': str(args.output)}))


if __name__ == '__main__':
    main()
