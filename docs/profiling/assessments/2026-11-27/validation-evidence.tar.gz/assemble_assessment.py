"""Local assembly helper; measurement runners and raw outputs remain untouched."""
import gzip
import json
import shutil
import sys
import tarfile
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
DEST = REPO / 'docs/profiling/assessments/2026-11-27'


def pack(destination, members):
    with destination.open('wb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0, compresslevel=9) as zipped:
            with tarfile.open(fileobj=zipped, mode='w') as archive:
                for path, name in sorted(members, key=lambda entry: entry[1]):
                    info = archive.gettarinfo(str(path), arcname=name)
                    info.mtime = 0
                    info.uid = info.gid = 0
                    info.uname = info.gname = ''
                    with path.open('rb') as stream:
                        archive.addfile(info, stream)
    print(destination.relative_to(REPO), destination.stat().st_size)


def native(name):
    source = REPO / 'output' / name
    target = DEST / name
    target.mkdir(exist_ok=True)
    for filename in ('config.json', 'provenance.json', 'status.json', 'report.json', 'report.csv'):
        path = source / filename
        if path.exists():
            shutil.copy2(path, target / filename)
    with (source / 'results.json').open('rb') as stream:
        with (target / 'results.json.gz').open('wb') as raw:
            with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as zipped:
                shutil.copyfileobj(stream, zipped)
    members = []
    for run in sorted((source / 'runs').iterdir()):
        if not run.is_dir():
            continue
        for filename in ('fixture.hsd', 'app.log', 'batch.log', 'result.json',
                         'measurement.json', 'measure-request.json', 'supervisor.log',
                         'config/hesiod/hesiod.json'):
            path = run / filename
            if path.is_file():
                members.append((path, str(path.relative_to(source))))
    for filename in ('source.diff', 'CMakeCache.txt'):
        path = source / filename
        if path.is_file():
            members.append((path, filename))
    for path in (source / 'scripts').rglob('*'):
        if path.is_file() and path.suffix in {'.py', '.json'}:
            members.append((path, str(path.relative_to(source))))
    pack(target / 'run-evidence.tar.gz', members)
    report = json.loads((source / 'report.json').read_text())
    print(name, 'complete=', report['complete'], 'growth=', report['memory_scaling_check'])


def validation():
    source = REPO / 'output/validation'
    extensions = {'.json', '.log', '.txt', '.sh', '.cmake', '.exit', '.stdout', '.utc', '.py', '.csv', '.jsonl'}
    paths = [p for p in source.iterdir() if p.is_file() and p.suffix in extensions]
    nested = source / 'gnode-sanitizers'
    if nested.exists():
        paths += [p for p in nested.rglob('*') if p.is_file() and p.suffix in extensions]
    preparations = source / 'preparation-errors'
    if preparations.exists():
        paths += [p for p in preparations.rglob('*')
                  if p.is_file()
                  and p.suffix in extensions | {'.py', '.csv'}
                  and not {'scripts', 'bin', 'data', '__pycache__'}.intersection(
                      p.relative_to(preparations).parts)]
    pack(DEST / 'validation-evidence.tar.gz', [(p, str(p.relative_to(source))) for p in paths])
    shutil.copy2(source / 'summary.json', DEST / 'validation-summary.json')


if __name__ == '__main__':
    for name in sys.argv[1:]:
        if name == 'validation':
            validation()
        else:
            native(name)
