#!/usr/bin/env bash
set -u
repo=/home/barrulus/dev/Hesiod-783
cd "$repo"
export QT_QPA_PLATFORM=offscreen
export OMP_NUM_THREADS=1
export XDG_CONFIG_HOME="$repo/output/validation/xdg-config"
export XDG_CACHE_HOME="$repo/output/validation/xdg-cache"
mkdir -p "$XDG_CONFIG_HOME" "$XDG_CACHE_HOME"
ctest --test-dir build/assessment --output-on-failure --timeout 180 > output/validation/ctest.log 2>&1
printf '%s\n' "$?" > output/validation/ctest.exit
(cd build/assessment/bin && timeout 180 ./hesiod_ui_palette_test) > output/validation/ui-palette.log 2>&1
printf '%s\n' "$?" > output/validation/ui-palette.exit
(cd build/assessment/bin && timeout 180 ./hesiod --check-port-links) > output/validation/check-port-links.log 2>&1
printf '%s\n' "$?" > output/validation/check-port-links.exit
HESIOD_BIN="$repo/build/assessment/bin/hesiod" output/validation/venv/bin/python -m pytest tests -q > output/validation/pytest-with-native.log 2>&1
printf '%s\n' "$?" > output/validation/pytest-with-native.exit
