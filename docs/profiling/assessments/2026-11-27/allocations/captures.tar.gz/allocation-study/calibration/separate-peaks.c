#include <stdlib.h>
#include <string.h>
#include <unistd.h>
__attribute__((noinline)) void first(void) {
  char *p=malloc(8*1024*1024); memset(p, 1, 8*1024*1024); usleep(100000); free(p);
}
__attribute__((noinline)) void second(void) {
  char *p=malloc(16*1024*1024); memset(p, 2, 16*1024*1024); usleep(100000); free(p);
}
int main(void) { first(); second(); return 0; }
