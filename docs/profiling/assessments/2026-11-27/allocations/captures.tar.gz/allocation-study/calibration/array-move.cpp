#include <type_traits>
#include "highmap/array.hpp"
static_assert(std::is_nothrow_move_constructible_v<hmap::Array>);
static_assert(std::is_nothrow_move_assignable_v<hmap::Array>);
