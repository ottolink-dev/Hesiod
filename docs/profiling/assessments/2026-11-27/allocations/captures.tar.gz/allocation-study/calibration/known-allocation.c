#include <stdlib.h>
#include <string.h>
#include <unistd.h>
int main(void) {
  char *a = malloc(8 * 1024 * 1024);
  if (!a) return 2;
  memset(a, 1, 8 * 1024 * 1024);
  usleep(100000);
  free(a);
  return 0;
}
